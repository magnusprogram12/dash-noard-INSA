document.addEventListener('DOMContentLoaded', async () => {
    let rawData = [];
    let salesChart = null;
    let topBuyersChart = null;

    // Load Data directly from global variable (injected by data.js)
    if (window.rawData) {
        rawData = window.rawData;
        initDashboard();
    } else {
        console.error("No data found in window.rawData");
        alert("No se encontraron datos. Por favor ejecuta el script 'scripts/process_data.py' nuevamente.");
    }

    function initDashboard() {
        populateFilters();
        updateDashboard('all');
        setupEventListeners();
    }

    function formatCurrency(value) {
        return new Intl.NumberFormat('es-CO', {
            style: 'currency',
            currency: 'COP',
            maximumFractionDigits: 0
        }).format(value);
    }

    function populateFilters() {
        const monthSelect = document.getElementById('monthFilter');
        const months = [...new Set(rawData.map(d => d.month))];

        // Sort months casually if possible, but they are strings like "Enero".
        // A simple map for ordering could be used, but raw order from CSV usually works if chronological.

        months.forEach(month => {
            if (!month) return;
            const option = document.createElement('option');
            option.value = month;
            option.textContent = month;
            monthSelect.appendChild(option);
        });
    }

    function updateDashboard(selectedMonth) {
        // Filter Data
        const filteredData = selectedMonth === 'all'
            ? rawData
            : rawData.filter(d => d.month === selectedMonth);

        // 1. Calculate KPIs
        const totalSales = filteredData.reduce((sum, item) => sum + item.value, 0);
        const totalTx = filteredData.length;
        const avgSales = totalTx > 0 ? totalSales / totalTx : 0;

        // Find Top Buyer
        const buyerMap = {};
        filteredData.forEach(item => {
            buyerMap[item.name] = (buyerMap[item.name] || 0) + item.value;
        });

        let topBuyerName = "-";
        let topBuyerVal = 0;
        Object.entries(buyerMap).forEach(([name, val]) => {
            if (val > topBuyerVal) {
                topBuyerVal = val;
                topBuyerName = name;
            }
        });

        // Update DOM
        animateValue("totalSales", totalSales, formatCurrency);
        animateValue("avgSales", avgSales, formatCurrency);
        document.getElementById('topBuyer').textContent = topBuyerName;
        document.getElementById('totalTransactions').textContent = totalTx;

        // 2. Charts
        updateCharts(filteredData, selectedMonth === 'all');
        updateTable(filteredData);
    }

    function animateValue(id, endValue, formatter) {
        const element = document.getElementById(id);
        const startValue = 0; // consistent start
        const duration = 1000;
        const startTime = Date.now();

        function update() {
            const now = Date.now();
            const elapsed = now - startTime;
            const progress = Math.min(elapsed / duration, 1);

            // Ease out quart
            const ease = 1 - Math.pow(1 - progress, 4);

            const current = startValue + (endValue - startValue) * ease;
            element.textContent = formatter(current);

            if (progress < 1) {
                requestAnimationFrame(update);
            }
        }
        update();
    }

    function updateCharts(data, isYearlyView) {
        const ctxSales = document.getElementById('salesChart').getContext('2d');
        const ctxBuyers = document.getElementById('topBuyersChart').getContext('2d');

        // Prepare Data for Sales Chart
        let labels = [];
        let values = [];

        if (isYearlyView) {
            // Group by Month
            const monthMap = {};
            // Use specific order if needed, otherwise occurrence order
            data.forEach(d => {
                if (!monthMap[d.month]) monthMap[d.month] = 0;
                monthMap[d.month] += d.value;
            });
            labels = Object.keys(monthMap);
            values = Object.values(monthMap);
        } else {
            // Show daily breakdown or just specific transactions? 
            // For a single month, maybe show daily if 'day' column existed/was parsed, 
            // but we only removed it. Let's show "Top Products/Descriptions" vs Value for the month
            // Or just grouped by buyer for the month.
            // Let's stick to Buyer breakdown for the main chart if in monthly view?
            // Actually, let's keep it simple: Monthly view -> still show totals, maybe no drill-down on time needed yet.
            // Let's just switch the main chart to "Sales by Buyer" in monthly view? 
            // Better: For "Comportamiento de Ventas", if Single Month, show by Description/Product Type if available?
            // "Description" is column D.
            const descMap = {};
            data.forEach(d => {
                if (!descMap[d.description]) descMap[d.description] = 0;
                descMap[d.description] += d.value;
            });
            // Sort top 10
            const sortedDesc = Object.entries(descMap).sort((a, b) => b[1] - a[1]).slice(0, 10);
            labels = sortedDesc.map(i => i[0]);
            values = sortedDesc.map(i => i[1]);
        }

        // Chart Config
        const gradient = ctxSales.createLinearGradient(0, 0, 0, 400);
        gradient.addColorStop(0, 'rgba(56, 189, 248, 0.5)');
        gradient.addColorStop(1, 'rgba(56, 189, 248, 0.0)');

        if (salesChart) salesChart.destroy();
        salesChart = new Chart(ctxSales, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Ventas',
                    data: values,
                    backgroundColor: gradient,
                    borderColor: '#38bdf8',
                    borderWidth: 1,
                    borderRadius: 4,
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: 'rgba(148, 163, 184, 0.1)' },
                        ticks: { color: '#94a3b8' }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { color: '#94a3b8' }
                    }
                }
            }
        });

        // Top Buyers Chart (Pie/Doughnut)
        const buyerMap = {};
        data.forEach(d => {
            buyerMap[d.name] = (buyerMap[d.name] || 0) + d.value;
        });
        const sortedBuyers = Object.entries(buyerMap)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 5); // Top 5

        if (topBuyersChart) topBuyersChart.destroy();
        topBuyersChart = new Chart(ctxBuyers, {
            type: 'doughnut',
            data: {
                labels: sortedBuyers.map(i => i[0]),
                datasets: [{
                    data: sortedBuyers.map(i => i[1]),
                    backgroundColor: [
                        '#38bdf8', '#818cf8', '#c084fc', '#f472b6', '#2dd4bf'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'right', labels: { color: '#94a3b8' } }
                }
            }
        });
    }

    function updateTable(data) {
        const tbody = document.getElementById('transactionTableBody');
        tbody.innerHTML = '';

        // Show max 50 rows for performance
        data.slice(0, 50).forEach(row => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td>${row.month}</td>
                <td>${row.name}</td>
                <td>${row.description}</td>
                <td class="text-right">${row.quantity}</td>
                <td class="text-right">${formatCurrency(row.value)}</td>
            `;
            tbody.appendChild(tr);
        });
    }

    function setupEventListeners() {
        document.getElementById('monthFilter').addEventListener('change', (e) => {
            updateDashboard(e.target.value);
        });

        // Sidebar Navigation
        document.querySelectorAll('.nav-item').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.nav-item').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                // Simple view toggle
                if (btn.dataset.view === 'details') {
                    document.querySelector('.kpi-grid').classList.add('hidden');
                    document.querySelector('.charts-grid').classList.add('hidden');
                    document.getElementById('transactionView').classList.remove('hidden');
                } else {
                    document.querySelector('.kpi-grid').classList.remove('hidden');
                    document.querySelector('.charts-grid').classList.remove('hidden');
                    document.getElementById('transactionView').classList.add('hidden');
                }
            });
        });
    }
});
