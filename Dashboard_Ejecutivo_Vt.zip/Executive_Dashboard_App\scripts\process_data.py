import csv
import json
import os
import re

def clean_currency(value):
    """Removes currency symbols and converts to float."""
    if not value:
        return 0.0
    # Remove $ and , and spaces
    clean_str = re.sub(r'[$,\s]', '', str(value))
    try:
        return float(clean_str)
    except ValueError:
        return 0.0

def process_csv(input_path, output_path):
    print(f"Reading from {input_path}...")
    
    data = []
    
    try:
        with open(input_path, 'r', encoding='utf-8') as f:
            reader = csv.reader(f)
            # Skip header if it exists, but looking at preview, header is line 1.
            # Preview showed: MES,NOMBRE,Q,D,VALOR
            header = next(reader, None)
            
            for row in reader:
                if len(row) < 5:
                    continue
                
                # Columns: 0=MES, 1=NOMBRE, 2=Q, 3=D, 4=VALOR
                # Stop if row is empty or malformed
                if not row[0]:
                    continue
                    
                record = {
                    "month": row[0].strip(),
                    "name": row[1].strip(),
                    "quantity": 0,
                    "description": row[3].strip(),
                    "value": clean_currency(row[4])
                }
                
                try:
                    record["quantity"] = int(row[2])
                except ValueError:
                    record["quantity"] = 0
                
                data.append(record)
                
    except Exception as e:
        print(f"Error reading CSV: {e}")
        # Try latin-1 if utf-8 fails
        try:
            print("Retrying with latin-1 encoding...")
            with open(input_path, 'r', encoding='latin-1') as f:
                reader = csv.reader(f)
                header = next(reader, None)
                for row in reader:
                    if len(row) < 5 or not row[0]: continue
                    record = {
                        "month": row[0].strip(),
                        "name": row[1].strip(),
                        "quantity": 0,
                        "description": row[3].strip(),
                        "value": clean_currency(row[4])
                    }
                    try:
                        record["quantity"] = int(row[2])
                    except:
                        record["quantity"] = 0
                    data.append(record)
        except Exception as e2:
            print(f"Final error reading CSV: {e2}")
            return

    print(f"Processed {len(data)} records.")
    
    # Ensure output directory exists
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    # Output as a JS file to avoid CORS issues with file:// protocol
    js_output_path = output_path.replace('.json', '.js')
    
    with open(js_output_path, 'w', encoding='utf-8') as f:
        json_str = json.dumps(data, ensure_ascii=False, indent=2)
        f.write(f"window.rawData = {json_str};")
    print(f"Saved JS data to {js_output_path}")

if __name__ == "__main__":
    # Adjust paths as needed
    INPUT_FILE = r"..\Hoja de cálculo sin título - Vt.csv"
    OUTPUT_FILE = r"..\Executive_Dashboard_App\public\data.json"
    
    # Check if we are running from scripts dir or root
    if os.path.basename(os.getcwd()) != "scripts":
        # Assuming running from 'Downloads' or similar, try to adjust
        if os.path.exists("Hoja de cálculo sin título - Vt.csv"):
             INPUT_FILE = "Hoja de cálculo sin título - Vt.csv"
             OUTPUT_FILE = r"Executive_Dashboard_App\public\data.json"
    
    process_csv(INPUT_FILE, OUTPUT_FILE)
