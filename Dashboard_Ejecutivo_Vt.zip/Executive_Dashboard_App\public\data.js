window.rawData = [
  {
    "month": "Enero",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 884000.0
  },
  {
    "month": "Enero",
    "name": "Cesar Perez",
    "quantity": 12,
    "description": "piezas",
    "value": 1801000.0
  },
  {
    "month": "Enero",
    "name": "Wilson Yama",
    "quantity": 4,
    "description": "piezas",
    "value": 512000.0
  },
  {
    "month": "Enero",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 850000.0
  },
  {
    "month": "Enero",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 884000.0
  },
  {
    "month": "Enero",
    "name": "Yamile Villamizar",
    "quantity": 2,
    "description": "piezas",
    "value": 308000.0
  },
  {
    "month": "Enero",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 985000.0
  },
  {
    "month": "Enero",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 897000.0
  },
  {
    "month": "Enero",
    "name": "Carlos Yama",
    "quantity": 24,
    "description": "piezas",
    "value": 3065000.0
  },
  {
    "month": "Enero",
    "name": "Javier Rojas",
    "quantity": 23,
    "description": "piezas",
    "value": 1100000.0
  },
  {
    "month": "Enero",
    "name": "Martha Alvarez",
    "quantity": 2,
    "description": "piezas",
    "value": 374000.0
  },
  {
    "month": "Enero",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 850000.0
  },
  {
    "month": "Enero",
    "name": "Alvacomer S.A.S",
    "quantity": 250,
    "description": "Tapas",
    "value": 212500.0
  },
  {
    "month": "Enero",
    "name": "bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 897000.0
  },
  {
    "month": "Enero",
    "name": "Mariela Barreto",
    "quantity": 3,
    "description": "piezas",
    "value": 478000.0
  },
  {
    "month": "Enero",
    "name": "Cali",
    "quantity": 3,
    "description": "piesas",
    "value": 917000.0
  },
  {
    "month": "Enero",
    "name": "Cali",
    "quantity": 3,
    "description": "piezas",
    "value": 599000.0
  },
  {
    "month": "Enero",
    "name": "Jorge Betin",
    "quantity": 21,
    "description": "piezas",
    "value": 1410000.0
  },
  {
    "month": "Enero",
    "name": "Jorde Valdez",
    "quantity": 5,
    "description": "piezas",
    "value": 573000.0
  },
  {
    "month": "Enero",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 850000.0
  },
  {
    "month": "Julio",
    "name": "Javier Rojas",
    "quantity": 14,
    "description": "piezas",
    "value": 3200000.0
  },
  {
    "month": "Enero",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 1237000.0
  },
  {
    "month": "Agosto",
    "name": "Javier Rojas",
    "quantity": 4,
    "description": "mantenimiento",
    "value": 140000.0
  },
  {
    "month": "Enero",
    "name": "Ricardo Virguez",
    "quantity": 157,
    "description": "cajas",
    "value": 1198000.0
  },
  {
    "month": "Enero",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 897000.0
  },
  {
    "month": "Enero",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 885000.0
  },
  {
    "month": "Febrero",
    "name": "Ricardo Virguez",
    "quantity": 3,
    "description": "piezas",
    "value": 1374000.0
  },
  {
    "month": "Agosto",
    "name": "Javier Rojas",
    "quantity": 21,
    "description": "piezas",
    "value": 2561000.0
  },
  {
    "month": "Febrero",
    "name": "Bogota",
    "quantity": 2,
    "description": "Practi",
    "value": 2306000.0
  },
  {
    "month": "Octubre",
    "name": "Javier Rojas",
    "quantity": 3,
    "description": "mantenimiento",
    "value": 129000.0
  },
  {
    "month": "Diciembre",
    "name": "Javier Rojas",
    "quantity": 8,
    "description": "piezas",
    "value": 1951000.0
  },
  {
    "month": "Febrero",
    "name": "Julieth Navarro",
    "quantity": 2,
    "description": "piezas",
    "value": 275000.0
  },
  {
    "month": "Febrero",
    "name": "Javier Rojas",
    "quantity": 11,
    "description": "piezas",
    "value": 1315000.0
  },
  {
    "month": "Enero",
    "name": "Nancy Calderon",
    "quantity": 2,
    "description": "piezas",
    "value": 424000.0
  },
  {
    "month": "Febrero",
    "name": "Cali",
    "quantity": 0,
    "description": "mantenimiento",
    "value": 411000.0
  },
  {
    "month": "Febrero",
    "name": "Ana Belinda lozano",
    "quantity": 6,
    "description": "piezas",
    "value": 106000.0
  },
  {
    "month": "Febrero",
    "name": "Edelmira Gomez",
    "quantity": 1,
    "description": "Junior",
    "value": 570000.0
  },
  {
    "month": "Febrero",
    "name": "Fernando Lemus",
    "quantity": 3,
    "description": "piezas",
    "value": 335000.0
  },
  {
    "month": "Febrero",
    "name": "Cali",
    "quantity": 1,
    "description": "piezas",
    "value": 1518000.0
  },
  {
    "month": "Enero",
    "name": "Katerin Morales",
    "quantity": 5,
    "description": "piezas",
    "value": 1088000.0
  },
  {
    "month": "Febrero",
    "name": "Camilo Niño",
    "quantity": 15,
    "description": "piezas",
    "value": 916000.0
  },
  {
    "month": "Febrero",
    "name": "Jorge Belin",
    "quantity": 3,
    "description": "piezas",
    "value": 774000.0
  },
  {
    "month": "Febrero",
    "name": "Luz Dary",
    "quantity": 2,
    "description": "piezas",
    "value": 262000.0
  },
  {
    "month": "Febrero",
    "name": "Edgardo Franco",
    "quantity": 1,
    "description": "piezas",
    "value": 158000.0
  },
  {
    "month": "Febrero",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 957000.0
  },
  {
    "month": "Febrero",
    "name": "Carlos Yama",
    "quantity": 2,
    "description": "piezas",
    "value": 140000.0
  },
  {
    "month": "Febrero",
    "name": "Jorde Valdez",
    "quantity": 10,
    "description": "piezas",
    "value": 747000.0
  },
  {
    "month": "Febrero",
    "name": "Ricardo Virguez",
    "quantity": 120,
    "description": "cajas",
    "value": 998000.0
  },
  {
    "month": "Febrero",
    "name": "Pedro Gerena",
    "quantity": 18,
    "description": "piezas",
    "value": 1948000.0
  },
  {
    "month": "Febrero",
    "name": "Nancy Calderón",
    "quantity": 2,
    "description": "piezas",
    "value": 308000.0
  },
  {
    "month": "Febrero",
    "name": "Yulieth Navarro",
    "quantity": 1,
    "description": "piezas",
    "value": 170000.0
  },
  {
    "month": "Febrero",
    "name": "Bogota",
    "quantity": 2,
    "description": "Practi",
    "value": 2068000.0
  },
  {
    "month": "Febrero",
    "name": "Carlos Yama",
    "quantity": 4,
    "description": "piezas",
    "value": 551000.0
  },
  {
    "month": "Febrero",
    "name": "Duitama",
    "quantity": 12,
    "description": "mantenimiento",
    "value": 233000.0
  },
  {
    "month": "Febrero",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 995000.0
  },
  {
    "month": "Febrero",
    "name": "Yamile Villamizar",
    "quantity": 1,
    "description": "piezas",
    "value": 140000.0
  },
  {
    "month": "Febrero",
    "name": "Edelmira Gomez",
    "quantity": 4,
    "description": "piezas",
    "value": 681000.0
  },
  {
    "month": "Febrero",
    "name": "Nancy Calderon",
    "quantity": 2,
    "description": "piezas",
    "value": 345000.0
  },
  {
    "month": "Febrero",
    "name": "Yamile Villamizar",
    "quantity": 1,
    "description": "piezas",
    "value": 120000.0
  },
  {
    "month": "Febrero",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Marzo",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Marzo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 990000.0
  },
  {
    "month": "Marzo",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Marzo",
    "name": "Gladys Yama",
    "quantity": 4,
    "description": "piezas",
    "value": 500000.0
  },
  {
    "month": "Marzo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Marzo",
    "name": "Ricardo Virguez",
    "quantity": 90,
    "description": "cajas",
    "value": 895000.0
  },
  {
    "month": "Marzo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 970000.0
  },
  {
    "month": "Marzo",
    "name": "Esperanza Avila",
    "quantity": 1,
    "description": "tortera",
    "value": 155000.0
  },
  {
    "month": "Marzo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Febrero",
    "name": "Jorde Valdez",
    "quantity": 3,
    "description": "mantenimiento",
    "value": 141000.0
  },
  {
    "month": "Febrero",
    "name": "Nancy Calderon",
    "quantity": 1,
    "description": "piezas",
    "value": 158000.0
  },
  {
    "month": "Marzo",
    "name": "Javier Rojas",
    "quantity": 5,
    "description": "piezas",
    "value": 250000.0
  },
  {
    "month": "Marzo",
    "name": "Jose Niño",
    "quantity": 1,
    "description": "piezas",
    "value": 187000.0
  },
  {
    "month": "Marzo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1045000.0
  },
  {
    "month": "Marzo",
    "name": "Esperanza Avila",
    "quantity": 11,
    "description": "piezas",
    "value": 734000.0
  },
  {
    "month": "Marzo",
    "name": "Carmenza Rico",
    "quantity": 3,
    "description": "piezas",
    "value": 355000.0
  },
  {
    "month": "Marzo",
    "name": "Marina Guzman",
    "quantity": 2,
    "description": "piezas",
    "value": 180000.0
  },
  {
    "month": "Febrero",
    "name": "Pedro Gerena",
    "quantity": 13,
    "description": "piezas",
    "value": 1618000.0
  },
  {
    "month": "Febrero",
    "name": "Zoraida Avila",
    "quantity": 14,
    "description": "piezas",
    "value": 956000.0
  },
  {
    "month": "Marzo",
    "name": "Ricardo Virguez",
    "quantity": 199,
    "description": "cajas",
    "value": 1386000.0
  },
  {
    "month": "Marzo",
    "name": "Martha Solarte",
    "quantity": 2,
    "description": "Practi",
    "value": 1886000.0
  },
  {
    "month": "Marzo",
    "name": "Fernando Lemus",
    "quantity": 1,
    "description": "piezas",
    "value": 190000.0
  },
  {
    "month": "Marzo",
    "name": "Cali",
    "quantity": 21,
    "description": "piezas",
    "value": 190000.0
  },
  {
    "month": "Marzo",
    "name": "Bogota",
    "quantity": 2,
    "description": "piezas",
    "value": 650000.0
  },
  {
    "month": "Marzo",
    "name": "Carmenza Rico",
    "quantity": 2,
    "description": "piezas",
    "value": 283000.0
  },
  {
    "month": "Marzo",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 930000.0
  },
  {
    "month": "Marzo",
    "name": "Jose Niño",
    "quantity": 2,
    "description": "piezas",
    "value": 280000.0
  },
  {
    "month": "Marzo",
    "name": "Javier Rojas",
    "quantity": 3,
    "description": "piezas",
    "value": 698000.0
  },
  {
    "month": "Febrero",
    "name": "Silverio Jimenez",
    "quantity": 3,
    "description": "piezas",
    "value": 307000.0
  },
  {
    "month": "Marzo",
    "name": "Cecilia Balcazan",
    "quantity": 1,
    "description": "piezas",
    "value": 87000.0
  },
  {
    "month": "Marzo",
    "name": "Claudia Garcia",
    "quantity": 1,
    "description": "piezas",
    "value": 237000.0
  },
  {
    "month": "Marzo",
    "name": "Ricardo Virguez",
    "quantity": 150,
    "description": "cajas",
    "value": 1248000.0
  },
  {
    "month": "Marzo",
    "name": "Cali",
    "quantity": 22,
    "description": "piezas",
    "value": 1592000.0
  },
  {
    "month": "Marzo",
    "name": "Gloria Alfonso",
    "quantity": 10,
    "description": "piezas",
    "value": 1137000.0
  },
  {
    "month": "Marzo",
    "name": "Carmenza Rico",
    "quantity": 3,
    "description": "piezas",
    "value": 368000.0
  },
  {
    "month": "Marzo",
    "name": "Ana Belinda lozano",
    "quantity": 4,
    "description": "piezas",
    "value": 666000.0
  },
  {
    "month": "Marzo",
    "name": "Silverio Jimenez",
    "quantity": 3,
    "description": "piezas",
    "value": 277000.0
  },
  {
    "month": "Marzo",
    "name": "Ricardo Virguez",
    "quantity": 142,
    "description": "cajas",
    "value": 983000.0
  },
  {
    "month": "Marzo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Marzo",
    "name": "Bogota",
    "quantity": 23,
    "description": "piezas",
    "value": 2078000.0
  },
  {
    "month": "Marzo",
    "name": "Jorge Valdez",
    "quantity": 18,
    "description": "piezas",
    "value": 1190000.0
  },
  {
    "month": "Marzo",
    "name": "Nancy Calderon",
    "quantity": 1,
    "description": "piezas",
    "value": 237000.0
  },
  {
    "month": "Marzo",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 957000.0
  },
  {
    "month": "Abril",
    "name": "Martha Forero",
    "quantity": 1,
    "description": "piezas",
    "value": 170000.0
  },
  {
    "month": "Abril",
    "name": "Carlos Yama",
    "quantity": 1,
    "description": "junior",
    "value": 485000.0
  },
  {
    "month": "Abril",
    "name": "Jose Niño",
    "quantity": 1,
    "description": "piezas",
    "value": 187000.0
  },
  {
    "month": "Marzo",
    "name": "Silverio Jimenez",
    "quantity": 1,
    "description": "piezas",
    "value": 176000.0
  },
  {
    "month": "Marzo",
    "name": "Miriam Parra",
    "quantity": 1,
    "description": "mantenimiento",
    "value": 30000.0
  },
  {
    "month": "Abril",
    "name": "Cali",
    "quantity": 2,
    "description": "Practi",
    "value": 1317000.0
  },
  {
    "month": "Abril",
    "name": "Ana Belinda lozano",
    "quantity": 2,
    "description": "piezas",
    "value": 275000.0
  },
  {
    "month": "Marzo",
    "name": "Katerin Morales",
    "quantity": 11,
    "description": "piezas",
    "value": 734000.0
  },
  {
    "month": "Abril",
    "name": "Gloria Alfonzo",
    "quantity": 2,
    "description": "piezas",
    "value": 215000.0
  },
  {
    "month": "Abril",
    "name": "Duitama",
    "quantity": 1,
    "description": "mantenimiento",
    "value": 275000.0
  },
  {
    "month": "Abril",
    "name": "Cali",
    "quantity": 21,
    "description": "equipo 21 piezas",
    "value": 1518000.0
  },
  {
    "month": "Abril",
    "name": "Edelmira Gomez",
    "quantity": 25,
    "description": "equipo 21 piezas",
    "value": 1249000.0
  },
  {
    "month": "Abril",
    "name": "Luz Marina Guzman",
    "quantity": 1,
    "description": "piezas",
    "value": 170000.0
  },
  {
    "month": "Abril",
    "name": "Gladys Yama",
    "quantity": 19,
    "description": "piezas",
    "value": 2613000.0
  },
  {
    "month": "Abril",
    "name": "Bogota",
    "quantity": 150,
    "description": "Practi",
    "value": 2179000.0
  },
  {
    "month": "Abril",
    "name": "Fernando Lemus",
    "quantity": 1,
    "description": "paellero",
    "value": 400000.0
  },
  {
    "month": "Abril",
    "name": "Javier Rojas",
    "quantity": 4,
    "description": "mantenimiento",
    "value": 135000.0
  },
  {
    "month": "Abril",
    "name": "Ricardo Virguez",
    "quantity": 18,
    "description": "piezas",
    "value": 1269000.0
  },
  {
    "month": "Marzo",
    "name": "Samuel Vargaz",
    "quantity": 1,
    "description": "piezas",
    "value": 140000.0
  },
  {
    "month": "Abril",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Abril",
    "name": "Ricardo Virguez",
    "quantity": 156,
    "description": "cajas",
    "value": 1088780.0
  },
  {
    "month": "Marzo",
    "name": "Yamile Villamizar",
    "quantity": 1,
    "description": "piezas",
    "value": 115000.0
  },
  {
    "month": "Abril",
    "name": "Ricardo Virguez",
    "quantity": 6,
    "description": "piezas",
    "value": 760000.0
  },
  {
    "month": "Abril",
    "name": "Fernando Lemus",
    "quantity": 3,
    "description": "piezas",
    "value": 265000.0
  },
  {
    "month": "Abril",
    "name": "Jorge Betin",
    "quantity": 21,
    "description": "piezas",
    "value": 1410000.0
  },
  {
    "month": "Abril",
    "name": "Julieth Navarro",
    "quantity": 1,
    "description": "piezas",
    "value": 204000.0
  },
  {
    "month": "Abril",
    "name": "Wilson Yama",
    "quantity": 2,
    "description": "piezas",
    "value": 175000.0
  },
  {
    "month": "Abril",
    "name": "Samuel Vargaz",
    "quantity": 1,
    "description": "piezas",
    "value": 115000.0
  },
  {
    "month": "Abril",
    "name": "Edelmira Gomez",
    "quantity": 1,
    "description": "junior",
    "value": 570000.0
  },
  {
    "month": "Abril",
    "name": "Ricardo Virguez",
    "quantity": 142,
    "description": "cajas",
    "value": 1006000.0
  },
  {
    "month": "Abril",
    "name": "Jeison btress",
    "quantity": 200,
    "description": "discos brillantes",
    "value": 5000.0
  },
  {
    "month": "Abril",
    "name": "Marta Solarte",
    "quantity": 8,
    "description": "Practi",
    "value": 1574000.0
  },
  {
    "month": "Abril",
    "name": "Fernando Garay",
    "quantity": 160,
    "description": "piezas",
    "value": 1695000.0
  },
  {
    "month": "Abril",
    "name": "Jorge Betin",
    "quantity": 4,
    "description": "paellero",
    "value": 903000.0
  },
  {
    "month": "Abril",
    "name": "Katerin Morales",
    "quantity": 12,
    "description": "piezas",
    "value": 824000.0
  },
  {
    "month": "Abril",
    "name": "Ricardo Virguez",
    "quantity": 4,
    "description": "piezas",
    "value": 390000.0
  },
  {
    "month": "Abril",
    "name": "Carmenza Rico",
    "quantity": 2,
    "description": "piezas",
    "value": 766000.0
  },
  {
    "month": "Abril",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Abril",
    "name": "Ricardo Virguez",
    "quantity": 121,
    "description": "cajas",
    "value": 1013000.0
  },
  {
    "month": "Abril",
    "name": "Duitama",
    "quantity": 3,
    "description": "piezas",
    "value": 1026000.0
  },
  {
    "month": "Abril",
    "name": "WESCO",
    "quantity": 5,
    "description": "piezas",
    "value": 595000.0
  },
  {
    "month": "Abril",
    "name": "Jeison btress",
    "quantity": 162,
    "description": "corte disco",
    "value": 129600.0
  },
  {
    "month": "Abril",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 941000.0
  },
  {
    "month": "Abril",
    "name": "Katerin Morales",
    "quantity": 1,
    "description": "piezas",
    "value": 158000.0
  },
  {
    "month": "Mayo",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 932000.0
  },
  {
    "month": "Mayo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1100000.0
  },
  {
    "month": "Mayo",
    "name": "Saray",
    "quantity": 1,
    "description": "piezas",
    "value": 85000.0
  },
  {
    "month": "Mayo",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 1299000.0
  },
  {
    "month": "Abril",
    "name": "Mariela Barrero",
    "quantity": 17,
    "description": "piezas",
    "value": 1153000.0
  },
  {
    "month": "Mayo",
    "name": "William Becerra",
    "quantity": 10,
    "description": "piezas",
    "value": 679000.0
  },
  {
    "month": "Mayo",
    "name": "Edgardo Franco",
    "quantity": 2,
    "description": "piezas",
    "value": 354000.0
  },
  {
    "month": "Mayo",
    "name": "Yolanda Ardila",
    "quantity": 2,
    "description": "piezas",
    "value": 180000.0
  },
  {
    "month": "Mayo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 975000.0
  },
  {
    "month": "Mayo",
    "name": "Edgardo Franco",
    "quantity": 1,
    "description": "equipo 13 piezas",
    "value": 831000.0
  },
  {
    "month": "Abril",
    "name": "Katerin Morales",
    "quantity": 12,
    "description": "piezas",
    "value": 824000.0
  },
  {
    "month": "Abril",
    "name": "Jorge Betin",
    "quantity": 3,
    "description": "paellero",
    "value": 1360000.0
  },
  {
    "month": "Mayo",
    "name": "Ricardo Virguez",
    "quantity": 174,
    "description": "cajas",
    "value": 1358000.0
  },
  {
    "month": "Mayo",
    "name": "Gloria Alfonzo",
    "quantity": 11,
    "description": "piezas",
    "value": 799000.0
  },
  {
    "month": "Abril",
    "name": "Katerin Morales",
    "quantity": 2,
    "description": "piezas",
    "value": 747000.0
  },
  {
    "month": "Mayo",
    "name": "Jorge Betin",
    "quantity": 1,
    "description": "equipo 21 piezas",
    "value": 1410000.0
  },
  {
    "month": "Mayo",
    "name": "Ricardo Virguez",
    "quantity": 150,
    "description": "cajas",
    "value": 1200000.0
  },
  {
    "month": "Mayo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Mayo",
    "name": "Gladys Yama",
    "quantity": 21,
    "description": "piezas",
    "value": 2445000.0
  },
  {
    "month": "Mayo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1770000.0
  },
  {
    "month": "Mayo",
    "name": "Jorge Betin",
    "quantity": 1,
    "description": "equipo 21 piezas",
    "value": 1410000.0
  },
  {
    "month": "Mayo",
    "name": "Jeison btress",
    "quantity": 253,
    "description": "troquelado disco",
    "value": 202400.0
  },
  {
    "month": "Mayo",
    "name": "Bogota",
    "quantity": 2,
    "description": "Practi",
    "value": 1886000.0
  },
  {
    "month": "Mayo",
    "name": "Ricardo Virguez",
    "quantity": 3,
    "description": "piezas",
    "value": 1612000.0
  },
  {
    "month": "Mayo",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1153000.0
  },
  {
    "month": "Mayo",
    "name": "Jeison btress",
    "quantity": 154,
    "description": "disco",
    "value": 1088500.0
  },
  {
    "month": "Mayo",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Mayo",
    "name": "Zoreida Avila",
    "quantity": 1,
    "description": "equipo 19 piezas",
    "value": 1338000.0
  },
  {
    "month": "Mayo",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1200000.0
  },
  {
    "month": "Mayo",
    "name": "Ricardo Virguez",
    "quantity": 147,
    "description": "cajas",
    "value": 1209000.0
  },
  {
    "month": "Junio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 975000.0
  },
  {
    "month": "Junio",
    "name": "Ricardo Virguez",
    "quantity": 120,
    "description": "cajas",
    "value": 960000.0
  },
  {
    "month": "Junio",
    "name": "Ricardo Virguez",
    "quantity": 3,
    "description": "piezas",
    "value": 428000.0
  },
  {
    "month": "Junio",
    "name": "William Becerra",
    "quantity": 2,
    "description": "junior",
    "value": 1600000.0
  },
  {
    "month": "Junio",
    "name": "Julieth Navarro",
    "quantity": 1,
    "description": "piezas",
    "value": 170000.0
  },
  {
    "month": "Junio",
    "name": "Mariela Murcia",
    "quantity": 6,
    "description": "piezas",
    "value": 682000.0
  },
  {
    "month": "Junio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1063000.0
  },
  {
    "month": "Junio",
    "name": "Ricardo Virguez",
    "quantity": 3,
    "description": "piezas",
    "value": 320000.0
  },
  {
    "month": "Junio",
    "name": "Orlando Suarez",
    "quantity": 1,
    "description": "junior",
    "value": 1025000.0
  },
  {
    "month": "Junio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 975000.0
  },
  {
    "month": "Junio",
    "name": "Enrique Guzman",
    "quantity": 40,
    "description": "soldadura",
    "value": 800000.0
  },
  {
    "month": "Junio",
    "name": "Orlando Suarez",
    "quantity": 2,
    "description": "Practi",
    "value": 100000.0
  },
  {
    "month": "Mayo",
    "name": "Jorge Betin",
    "quantity": 1,
    "description": "equipo 21 piezas",
    "value": 1410000.0
  },
  {
    "month": "Junio",
    "name": "Bogota",
    "quantity": 2,
    "description": "Practi",
    "value": 2491000.0
  },
  {
    "month": "Junio",
    "name": "Lola Chacón",
    "quantity": 1,
    "description": "piezas",
    "value": 125000.0
  },
  {
    "month": "Junio",
    "name": "Mariela Murcia",
    "quantity": 2,
    "description": "piezas",
    "value": 240000.0
  },
  {
    "month": "Junio",
    "name": "Ricardo Virguez",
    "quantity": 108,
    "description": "cajas",
    "value": 734000.0
  },
  {
    "month": "Junio",
    "name": "Ricardo Virguez",
    "quantity": 5,
    "description": "piezas",
    "value": 346000.0
  },
  {
    "month": "Junio",
    "name": "Carlos Yama",
    "quantity": 7,
    "description": "piezas",
    "value": 1114000.0
  },
  {
    "month": "Junio",
    "name": "Carlos Yama",
    "quantity": 9,
    "description": "piezas",
    "value": 1035000.0
  },
  {
    "month": "Junio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 1343000.0
  },
  {
    "month": "Junio",
    "name": "Marina Guzman",
    "quantity": 2,
    "description": "piezas",
    "value": 180000.0
  },
  {
    "month": "Mayo",
    "name": "Katerin Morales",
    "quantity": 13,
    "description": "piezas",
    "value": 804000.0
  },
  {
    "month": "Junio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 1137000.0
  },
  {
    "month": "Junio",
    "name": "Vicente Cardenaz",
    "quantity": 2,
    "description": "piezas",
    "value": 697000.0
  },
  {
    "month": "Junio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 975000.0
  },
  {
    "month": "Junio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Mayo",
    "name": "Yamile Villamizar",
    "quantity": 2,
    "description": "piezas",
    "value": 390000.0
  },
  {
    "month": "Junio",
    "name": "Ricardo Virguez",
    "quantity": 143,
    "description": "cajas",
    "value": 972000.0
  },
  {
    "month": "Junio",
    "name": "Bogota",
    "quantity": 2,
    "description": "Practi",
    "value": 1886000.0
  },
  {
    "month": "Junio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1128000.0
  },
  {
    "month": "Junio",
    "name": "Edgardo Franco",
    "quantity": 3,
    "description": "piezas",
    "value": 207000.0
  },
  {
    "month": "Junio",
    "name": "Sara Mariela",
    "quantity": 2,
    "description": "mantenimiento",
    "value": 35000.0
  },
  {
    "month": "Junio",
    "name": "Cecilia Rodriguez",
    "quantity": 1,
    "description": "piezas",
    "value": 68000.0
  },
  {
    "month": "Julio",
    "name": "Carlos Yama",
    "quantity": 2,
    "description": "piezas",
    "value": 1458000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 3,
    "description": "Practi",
    "value": 2803000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 978000.0
  },
  {
    "month": "Julio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1494000.0
  },
  {
    "month": "Julio",
    "name": "Nacy Calderon",
    "quantity": 1,
    "description": "piezas",
    "value": 125000.0
  },
  {
    "month": "Julio",
    "name": "Marta Solarte",
    "quantity": 13,
    "description": "piezas",
    "value": 1323000.0
  },
  {
    "month": "Mayo",
    "name": "Pedro Genera",
    "quantity": 14,
    "description": "piezas",
    "value": 1704000.0
  },
  {
    "month": "Julio",
    "name": "Jeison btress",
    "quantity": 144,
    "description": "brazas pulir",
    "value": 1188000.0
  },
  {
    "month": "Julio",
    "name": "Sra Abigail Cartagena",
    "quantity": 2,
    "description": "olleta multiuso",
    "value": 1822000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 5,
    "description": "piezas",
    "value": 648000.0
  },
  {
    "month": "Julio",
    "name": "Gloria Alfonso",
    "quantity": 1,
    "description": "junior",
    "value": 570000.0
  },
  {
    "month": "Julio",
    "name": "Ricardo Virguez",
    "quantity": 1,
    "description": "piezas",
    "value": 85000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Julio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1030000.0
  },
  {
    "month": "Julio",
    "name": "Gloria Alfonso",
    "quantity": 1,
    "description": "junior",
    "value": 845000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Julio",
    "name": "Nuri",
    "quantity": 18,
    "description": "piezas",
    "value": 1599000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Julio",
    "name": "Leonardo Rivera",
    "quantity": 7,
    "description": "piezas",
    "value": 809000.0
  },
  {
    "month": "Julio",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Julio",
    "name": "Jeison btress",
    "quantity": 287,
    "description": "discos",
    "value": 287000.0
  },
  {
    "month": "Julio",
    "name": "William Becerra",
    "quantity": 13,
    "description": "piezas",
    "value": 831000.0
  },
  {
    "month": "Mayo",
    "name": "Silverio Jimenez",
    "quantity": 2,
    "description": "piezas",
    "value": 215000.0
  },
  {
    "month": "Julio",
    "name": "Yolanda Ardila",
    "quantity": 5,
    "description": "piezas",
    "value": 580000.0
  },
  {
    "month": "Julio",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Julio",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 95000.0
  },
  {
    "month": "Julio",
    "name": "Esperanza Avila",
    "quantity": 11,
    "description": "piezas",
    "value": 739000.0
  },
  {
    "month": "Julio",
    "name": "Carlos Yama",
    "quantity": 2,
    "description": "piezas",
    "value": 262000.0
  },
  {
    "month": "Julio",
    "name": "Mariela Murcia",
    "quantity": 8,
    "description": "piezas",
    "value": 1007000.0
  },
  {
    "month": "Julio",
    "name": "Gladys Yama",
    "quantity": 11,
    "description": "piezas",
    "value": 1164000.0
  },
  {
    "month": "Junio",
    "name": "Imelda Sanchez",
    "quantity": 3,
    "description": "piezas",
    "value": 412000.0
  },
  {
    "month": "Agosto",
    "name": "Carlos Yama",
    "quantity": 1,
    "description": "piezas",
    "value": 426000.0
  },
  {
    "month": "Agosto",
    "name": "Yolanda Ardila",
    "quantity": 3,
    "description": "piezas",
    "value": 411000.0
  },
  {
    "month": "Agosto",
    "name": "Esperanza Avila",
    "quantity": 2,
    "description": "piezas",
    "value": 220000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 2,
    "description": "Practi",
    "value": 1886000.0
  },
  {
    "month": "Agosto",
    "name": "Vicente Cardenaz",
    "quantity": 1,
    "description": "mantenimiento",
    "value": 40000.0
  },
  {
    "month": "Junio",
    "name": "Katerin Morales",
    "quantity": 11,
    "description": "piezas",
    "value": 734000.0
  },
  {
    "month": "Agosto",
    "name": "Sergio Ornamentador",
    "quantity": 2,
    "description": "piezas",
    "value": 100000.0
  },
  {
    "month": "Agosto",
    "name": "Guillermo Gonzales",
    "quantity": 1,
    "description": "piezas",
    "value": 125000.0
  },
  {
    "month": "Junio",
    "name": "Pedro Genera",
    "quantity": 10,
    "description": "piezas",
    "value": 1072000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 931000.0
  },
  {
    "month": "Agosto",
    "name": "Edgardo Franco",
    "quantity": 2,
    "description": "piezas",
    "value": 180000.0
  },
  {
    "month": "Julio",
    "name": "Samuel Vargas",
    "quantity": 3,
    "description": "piezas",
    "value": 506000.0
  },
  {
    "month": "Agosto",
    "name": "Ricardo Virguez",
    "quantity": 2,
    "description": "piezas",
    "value": 1357000.0
  },
  {
    "month": "Julio",
    "name": "Samuel Vargas",
    "quantity": 4,
    "description": "piezas",
    "value": 620000.0
  },
  {
    "month": "Agosto",
    "name": "William Becerra",
    "quantity": 2,
    "description": "piezas",
    "value": 320000.0
  },
  {
    "month": "Agosto",
    "name": "Ricardo Virguez",
    "quantity": 6,
    "description": "piezas",
    "value": 425000.0
  },
  {
    "month": "Agosto",
    "name": "Mariela Malaver",
    "quantity": 1,
    "description": "piezas",
    "value": 204000.0
  },
  {
    "month": "Agosto",
    "name": "Samuel Vargas",
    "quantity": 5,
    "description": "piezas",
    "value": 480000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 1044000.0
  },
  {
    "month": "Agosto",
    "name": "Ricardo Virguez",
    "quantity": 115,
    "description": "cajas",
    "value": 105000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Agosto",
    "name": "Edgardo Franco",
    "quantity": 13,
    "description": "piezas",
    "value": 831000.0
  },
  {
    "month": "Agosto",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1098000.0
  },
  {
    "month": "Agosto",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 936000.0
  },
  {
    "month": "Agosto",
    "name": "Pedro Genera",
    "quantity": 1,
    "description": "junior",
    "value": 570000.0
  },
  {
    "month": "Agosto",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1045000.0
  },
  {
    "month": "Agosto",
    "name": "Ricardo Virguez",
    "quantity": 60,
    "description": "cajas",
    "value": 606000.0
  },
  {
    "month": "Agosto",
    "name": "Dora",
    "quantity": 2,
    "description": "mantenimiento",
    "value": 85000.0
  },
  {
    "month": "Agosto",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Agosto",
    "name": "Mariela Barreto",
    "quantity": 4,
    "description": "piezas",
    "value": 429000.0
  },
  {
    "month": "Agosto",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1268000.0
  },
  {
    "month": "Agosto",
    "name": "Samuel Vargas",
    "quantity": 4,
    "description": "piezas",
    "value": 572000.0
  },
  {
    "month": "Agosto",
    "name": "Sandra Salina",
    "quantity": 1,
    "description": "piezas",
    "value": 90000.0
  },
  {
    "month": "Agosto",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1288000.0
  },
  {
    "month": "Agosto",
    "name": "William Becerra",
    "quantity": 1,
    "description": "olleta multiuso",
    "value": 779000.0
  },
  {
    "month": "Agosto",
    "name": "Saray",
    "quantity": 1,
    "description": "piezas",
    "value": 125000.0
  },
  {
    "month": "Agosto",
    "name": "Cali",
    "quantity": 1,
    "description": "equipo 21 piesas",
    "value": 1518000.0
  },
  {
    "month": "Agosto",
    "name": "Ricardo Virguez",
    "quantity": 97,
    "description": "cajas",
    "value": 968000.0
  },
  {
    "month": "Agosto",
    "name": "Katerin Morales",
    "quantity": 10,
    "description": "piezas",
    "value": 1215000.0
  },
  {
    "month": "Agosto",
    "name": "Ricardo Virguez",
    "quantity": 5,
    "description": "piezas",
    "value": 1439000.0
  },
  {
    "month": "Agosto",
    "name": "Imelda Sanchez",
    "quantity": 4,
    "description": "piezas",
    "value": 485000.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 2,
    "description": "Practi",
    "value": 1848000.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 2,
    "description": "Practi",
    "value": 1980000.0
  },
  {
    "month": "Septiembre",
    "name": "William Becerra",
    "quantity": 3,
    "description": "piezas",
    "value": 345000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 107,
    "description": "cajas",
    "value": 727000.0
  },
  {
    "month": "Agosto",
    "name": "Katerin Morales",
    "quantity": 13,
    "description": "piezas",
    "value": 1008000.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 7,
    "description": "piezas",
    "value": 1012000.0
  },
  {
    "month": "Septiembre",
    "name": "Esperanza Avila",
    "quantity": 2,
    "description": "piezas",
    "value": 310000.0
  },
  {
    "month": "Septiembre",
    "name": "Marliela Murcia",
    "quantity": 3,
    "description": "piezas",
    "value": 373000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 9,
    "description": "piezas",
    "value": 1014930.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 20,
    "description": "mantenimiento",
    "value": 460000.0
  },
  {
    "month": "Septiembre",
    "name": "Yolanda Ardila",
    "quantity": 5,
    "description": "piezas",
    "value": 1201000.0
  },
  {
    "month": "Agosto",
    "name": "Nora Cedeño",
    "quantity": 1,
    "description": "piezas",
    "value": 85000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 18,
    "description": "piezas",
    "value": 954990.0
  },
  {
    "month": "Septiembre",
    "name": "Bogota",
    "quantity": 3,
    "description": "Practi",
    "value": 1196000.0
  },
  {
    "month": "Septiembre",
    "name": "Fredy Guzman",
    "quantity": 1,
    "description": "piezas",
    "value": 115000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 9,
    "description": "piezas",
    "value": 966380.0
  },
  {
    "month": "Septiembre",
    "name": "Edgardo Franco",
    "quantity": 1,
    "description": "junior",
    "value": 570000.0
  },
  {
    "month": "Septiembre",
    "name": "Edelmira Gomez",
    "quantity": 17,
    "description": "piezas",
    "value": 1083000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 9,
    "description": "piezas",
    "value": 613980.0
  },
  {
    "month": "Septiembre",
    "name": "Hugo Bernal",
    "quantity": 11,
    "description": "piezas",
    "value": 708000.0
  },
  {
    "month": "Septiembre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 957000.0
  },
  {
    "month": "Septiembre",
    "name": "Samuel Vargas",
    "quantity": 1,
    "description": "bateria 10 piezas",
    "value": 679000.0
  },
  {
    "month": "Septiembre",
    "name": "Jeison btress",
    "quantity": 501,
    "description": "otros",
    "value": 1245000.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 3,
    "description": "piezas",
    "value": 1421000.0
  },
  {
    "month": "Septiembre",
    "name": "William Becerra",
    "quantity": 5,
    "description": "piezas",
    "value": 173000.0
  },
  {
    "month": "Septiembre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 450000.0
  },
  {
    "month": "Septiembre",
    "name": "Pedro Genera",
    "quantity": 17,
    "description": "piezas",
    "value": 1666000.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Septiembre",
    "name": "Zoraida Avila",
    "quantity": 1,
    "description": "junior",
    "value": 640000.0
  },
  {
    "month": "Septiembre",
    "name": "Carlos Yama",
    "quantity": 4,
    "description": "piezas",
    "value": 666000.0
  },
  {
    "month": "Septiembre",
    "name": "Yolanda Ardila",
    "quantity": 1,
    "description": "plancha imperfecta",
    "value": 100000.0
  },
  {
    "month": "Septiembre",
    "name": "Cali",
    "quantity": 22,
    "description": "piezas",
    "value": 1518000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 141,
    "description": "cajas",
    "value": 1078000.0
  },
  {
    "month": "Septiembre",
    "name": "Ricardo Virguez",
    "quantity": 2,
    "description": "piezas",
    "value": 149850.0
  },
  {
    "month": "Septiembre",
    "name": "Bogota",
    "quantity": 2,
    "description": "Practi",
    "value": 2025000.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 9,
    "description": "mantenimiento",
    "value": 280000.0
  },
  {
    "month": "Septiembre",
    "name": "Prospero",
    "quantity": 10,
    "description": "piezas",
    "value": 1750000.0
  },
  {
    "month": "Septiembre",
    "name": "Katerin Morales",
    "quantity": 5,
    "description": "piezas",
    "value": 485000.0
  },
  {
    "month": "Septiembre",
    "name": "Esperanza Avila",
    "quantity": 2,
    "description": "piezas",
    "value": 172000.0
  },
  {
    "month": "Septiembre",
    "name": "Marta Solarte",
    "quantity": 2,
    "description": "junior y practi",
    "value": 1584000.0
  },
  {
    "month": "Septiembre",
    "name": "Duitama",
    "quantity": 2,
    "description": "Practi",
    "value": 1025000.0
  },
  {
    "month": "Octubre",
    "name": "Ricardo Virguez",
    "quantity": 211,
    "description": "cajas",
    "value": 1469000.0
  },
  {
    "month": "Septiembre",
    "name": "Silverio Jimenez",
    "quantity": 3,
    "description": "piezas",
    "value": 325000.0
  },
  {
    "month": "Octubre",
    "name": "Agustin Carranza",
    "quantity": 1,
    "description": "equipo 21 piesas",
    "value": 1410000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 9,
    "description": "mantenimiento",
    "value": 81000.0
  },
  {
    "month": "Octubre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Octubre",
    "name": "Edgardo Franco",
    "quantity": 1,
    "description": "equipo 15 piezas",
    "value": 916000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 9,
    "description": "piezas",
    "value": 81000.0
  },
  {
    "month": "Septiembre",
    "name": "Imelda Sanchez",
    "quantity": 1,
    "description": "piezas",
    "value": 140000.0
  },
  {
    "month": "Octubre",
    "name": "Carmenza Rico",
    "quantity": 1,
    "description": "piezas",
    "value": 125000.0
  },
  {
    "month": "Octubre",
    "name": "Carmenza Rico",
    "quantity": 3,
    "description": "piezas",
    "value": 265000.0
  },
  {
    "month": "Octubre",
    "name": "Carlos Toledo",
    "quantity": 1,
    "description": "piezas",
    "value": 155000.0
  },
  {
    "month": "Octubre",
    "name": "Mariela Barreto",
    "quantity": 2,
    "description": "piezas",
    "value": 307000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1198000.0
  },
  {
    "month": "Octubre",
    "name": "Gloria Alfonso",
    "quantity": 1,
    "description": "junior",
    "value": 583000.0
  },
  {
    "month": "Octubre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 1088000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1306000.0
  },
  {
    "month": "Octubre",
    "name": "Bogota",
    "quantity": 1,
    "description": "junior",
    "value": 580000.0
  },
  {
    "month": "Octubre",
    "name": "Mariela Barreto",
    "quantity": 2,
    "description": "piezas",
    "value": 600000.0
  },
  {
    "month": "Octubre",
    "name": "Fernando Romero",
    "quantity": 1,
    "description": "equipo 17 piezas",
    "value": 1153000.0
  },
  {
    "month": "Octubre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 1,
    "description": "equipo 21 piesas",
    "value": 1518000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Octubre",
    "name": "Jorge Betin",
    "quantity": 3,
    "description": "equipo 21 piesas",
    "value": 3660000.0
  },
  {
    "month": "Octubre",
    "name": "Samuel Vargas",
    "quantity": 1,
    "description": "piezas",
    "value": 140000.0
  },
  {
    "month": "Octubre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 990000.0
  },
  {
    "month": "Octubre",
    "name": "Ricardo Virguez",
    "quantity": 1,
    "description": "equipo 17 piezas",
    "value": 1153000.0
  },
  {
    "month": "Octubre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 1077000.0
  },
  {
    "month": "Octubre",
    "name": "Edgardo Franco",
    "quantity": 1,
    "description": "piezas",
    "value": 204000.0
  },
  {
    "month": "Octubre",
    "name": "Ricardo Virguez",
    "quantity": 190,
    "description": "cajas",
    "value": 1377000.0
  },
  {
    "month": "Octubre",
    "name": "Silverio Jimenez",
    "quantity": 4,
    "description": "piezas",
    "value": 475000.0
  },
  {
    "month": "Octubre",
    "name": "Pedro Genera",
    "quantity": 36,
    "description": "piezas",
    "value": 2429000.0
  },
  {
    "month": "Octubre",
    "name": "Nora Cedeño",
    "quantity": 2,
    "description": "piezas",
    "value": 170000.0
  },
  {
    "month": "Octubre",
    "name": "Gloria Alfonso",
    "quantity": 1,
    "description": "piezas",
    "value": 45000.0
  },
  {
    "month": "Octubre",
    "name": "Fernando Lemus",
    "quantity": 4,
    "description": "piezas",
    "value": 495000.0
  },
  {
    "month": "Octubre",
    "name": "Katerin Morales",
    "quantity": 1,
    "description": "equipo 10 piezas",
    "value": 739000.0
  },
  {
    "month": "Octubre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Octubre",
    "name": "Mariela Barreto",
    "quantity": 3,
    "description": "piezas",
    "value": 350000.0
  },
  {
    "month": "Octubre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Octubre",
    "name": "Imelda Sanchez",
    "quantity": 3,
    "description": "piezas",
    "value": 596000.0
  },
  {
    "month": "Octubre",
    "name": "Samuel Vargas",
    "quantity": 1,
    "description": "piezas",
    "value": 35000.0
  },
  {
    "month": "Octubre",
    "name": "Bogota",
    "quantity": 1,
    "description": "junior",
    "value": 580000.0
  },
  {
    "month": "Octubre",
    "name": "Duitama",
    "quantity": 2,
    "description": "Practi",
    "value": 1241000.0
  },
  {
    "month": "Octubre",
    "name": "Carlos Yama",
    "quantity": 1,
    "description": "piezas",
    "value": 176000.0
  },
  {
    "month": "Octubre",
    "name": "Jaime Cortez",
    "quantity": 2,
    "description": "piezas",
    "value": 343000.0
  },
  {
    "month": "Octubre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Octubre",
    "name": "Silverio Jimenez",
    "quantity": 3,
    "description": "piezas",
    "value": 355000.0
  },
  {
    "month": "Noviembre",
    "name": "Ana Belinda lozano",
    "quantity": 1,
    "description": "equipo 10 piezas",
    "value": 906000.0
  },
  {
    "month": "Noviembre",
    "name": "Edi Ortegon",
    "quantity": 3,
    "description": "piezas",
    "value": 385000.0
  },
  {
    "month": "Noviembre",
    "name": "Ricardo Virguez",
    "quantity": 143,
    "description": "cajas",
    "value": 1179000.0
  },
  {
    "month": "Noviembre",
    "name": "Gloria Alfonso",
    "quantity": 1,
    "description": "junior",
    "value": 570000.0
  },
  {
    "month": "Noviembre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 957000.0
  },
  {
    "month": "Noviembre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 917000.0
  },
  {
    "month": "Noviembre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1015000.0
  },
  {
    "month": "Noviembre",
    "name": "Wilson Yama",
    "quantity": 5,
    "description": "piezas",
    "value": 627000.0
  },
  {
    "month": "Noviembre",
    "name": "Elmira Gomez",
    "quantity": 1,
    "description": "equipo 13 piezas",
    "value": 831000.0
  },
  {
    "month": "Noviembre",
    "name": "Carlos Yama",
    "quantity": 1,
    "description": "equipo 12 piezas",
    "value": 982000.0
  },
  {
    "month": "Noviembre",
    "name": "Nuri",
    "quantity": 40,
    "description": "piezas",
    "value": 3816000.0
  },
  {
    "month": "Noviembre",
    "name": "Katerin Morales",
    "quantity": 2,
    "description": "equipo 10 piezas",
    "value": 1468000.0
  },
  {
    "month": "Noviembre",
    "name": "Duitama",
    "quantity": 2,
    "description": "piezas",
    "value": 333000.0
  },
  {
    "month": "Noviembre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Noviembre",
    "name": "Mariela Murcia",
    "quantity": 1,
    "description": "equipo 10 piezas",
    "value": 722000.0
  },
  {
    "month": "Noviembre",
    "name": "Edgardo Franco",
    "quantity": 2,
    "description": "piezas",
    "value": 215000.0
  },
  {
    "month": "Noviembre",
    "name": "Wilson Yama",
    "quantity": 1,
    "description": "piezas",
    "value": 137000.0
  },
  {
    "month": "Diciembre",
    "name": "Johana Vargaz",
    "quantity": 1,
    "description": "equipo 17 piezas",
    "value": 1020000.0
  },
  {
    "month": "Diciembre",
    "name": "Imelda Sanchez",
    "quantity": 7,
    "description": "piezas",
    "value": 700000.0
  },
  {
    "month": "Diciembre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 955000.0
  },
  {
    "month": "Diciembre",
    "name": "Julieth Navarro",
    "quantity": 1,
    "description": "piezas",
    "value": 180000.0
  },
  {
    "month": "Diciembre",
    "name": "Pedro Genera",
    "quantity": 18,
    "description": "piezas",
    "value": 2382000.0
  },
  {
    "month": "Diciembre",
    "name": "Bogota",
    "quantity": 1,
    "description": "junior",
    "value": 580000.0
  },
  {
    "month": "Diciembre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Diciembre",
    "name": "Yamile Villamizar",
    "quantity": 3,
    "description": "piezas",
    "value": 865000.0
  },
  {
    "month": "Diciembre",
    "name": "Camilo Niño",
    "quantity": 1,
    "description": "junior",
    "value": 570000.0
  },
  {
    "month": "Diciembre",
    "name": "Gladys Yama",
    "quantity": 1,
    "description": "piezas",
    "value": 180000.0
  },
  {
    "month": "Diciembre",
    "name": "Ricardo Virguez",
    "quantity": 143,
    "description": "cajas",
    "value": 1144000.0
  },
  {
    "month": "Diciembre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 957000.0
  },
  {
    "month": "Diciembre",
    "name": "Samuel Vargas",
    "quantity": 4,
    "description": "piezas",
    "value": 396000.0
  },
  {
    "month": "Diciembre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Diciembre",
    "name": "Duitama",
    "quantity": 1,
    "description": "equipo 13 piezas",
    "value": 831000.0
  },
  {
    "month": "Diciembre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Luna de Miel",
    "value": 643000.0
  },
  {
    "month": "Diciembre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  },
  {
    "month": "Diciembre",
    "name": "Ricardo Virguez",
    "quantity": 93,
    "description": "cajas",
    "value": 648000.0
  },
  {
    "month": "Diciembre",
    "name": "Cali",
    "quantity": 1,
    "description": "equipo 21 piesas",
    "value": 1518000.0
  },
  {
    "month": "Diciembre",
    "name": "Katerin Morales",
    "quantity": 1,
    "description": "equipo 10 piezas",
    "value": 734000.0
  },
  {
    "month": "Diciembre",
    "name": "Cesar Augusto",
    "quantity": 3,
    "description": "piezas",
    "value": 347000.0
  },
  {
    "month": "Diciembre",
    "name": "Bogota",
    "quantity": 1,
    "description": "junior",
    "value": 580000.0
  },
  {
    "month": "Diciembre",
    "name": "Elmira Gomez",
    "quantity": 1,
    "description": "mantenimiento",
    "value": 20000.0
  },
  {
    "month": "Diciembre",
    "name": "Cali",
    "quantity": 1,
    "description": "Practi",
    "value": 1020000.0
  },
  {
    "month": "Diciembre",
    "name": "Duitama",
    "quantity": 1,
    "description": "Practi",
    "value": 1087000.0
  },
  {
    "month": "Diciembre",
    "name": "Bogota",
    "quantity": 1,
    "description": "Practi",
    "value": 969000.0
  }
];